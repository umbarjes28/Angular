import { EmployeeData } from './employee-data';

describe('EmployeeData', () => {
  it('should create an instance', () => {
    expect(new EmployeeData()).toBeTruthy();
  });
});
