import { Component, OnInit, AfterViewInit, OnDestroy, ViewChildren, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, FormArray, Validators, FormControlName } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { Observable, Subscription, fromEvent, merge } from 'rxjs';
import { debounceTime } from 'rxjs/operators';
import { EmployeeService } from './employee.service';
import { Employee } from './employee';
import { GenericValidator } from '../shared/generic-validator';



@Component({
  selector: 'app-employee-add',
  templateUrl: './employee-add.component.html',
  styleUrls: ['./employee-add.component.css']
})
export class EmployeeAddComponent implements OnInit {
  @ViewChildren(FormControlName, { read: ElementRef }) formInputElements: ElementRef[];
  pageTitle = 'Add Employee';
  employeeForm: FormGroup;
  private sub: Subscription;
  Employee: Employee;
  errorMessage: string;
  public LanguagesName: any[] = [];
  QualificationName: any = ['Bachelor','Master','Doctorate'];
  displayMessage: {[key: string]: string} ={};
  private validationMessages: {[key: string]: {[key: string]: string }};
  private genericValidator: GenericValidator;

  constructor(private fb: FormBuilder, private employeeService: EmployeeService, private router: Router,private route: ActivatedRoute)
  {
    this.LanguagesName = [
      'Marathi','Hindi','English','Gujarati'
    ];

    this.validationMessages = {
      Name: {
        required: 'Employee Name is required',
        minLength: 'Employee Name must be at least thee character'
      },
      Qualification:
      {
        required: 'Qualification is required'
      },
      Experience:
      {
        required: 'Experience is required'
      },
      Languages:
      {
        required: 'Languages is required'
      }
    };

    this.genericValidator = new GenericValidator(this.validationMessages);
  }

  ngOnDestroy(): void {
    this.sub.unsubscribe();
  }

   ngAfterViewInit(): void {
    // Watch for the blur event from any input element on the form.
    // This is required because the valueChanges does not provide notification on blur
    const controlBlurs: Observable<any>[] = this.formInputElements
      .map((formControl: ElementRef) => fromEvent(formControl.nativeElement, 'blur'));

    // Merge the blur event observable with the valueChanges observable
    // so we only need to subscribe once.
    merge(this.employeeForm.valueChanges, ...controlBlurs).pipe(
      debounceTime(800)
    ).subscribe(value => {
      this.displayMessage = this.genericValidator.processMessages(this.employeeForm);
    });
  }

  ngOnInit() {
    this.employeeForm = this.fb.group({
      Name: ['', [
        Validators.required,
        Validators.minLength(3)]],
      Qualification: ['', Validators.required],
      Experience: ['', Validators.required],
      Languages : ['', Validators.required]
    });

    // Read the employee Id from the route parameter
    this.sub = this.route.paramMap.subscribe(
      params => {
        const id = +params.get('id');
        this.getEmployee(id);
      }
    );
  }
  get Languages() {
    return this.employeeForm.get('LanguagesName');
  }
  getEmployee(id: number): void {
    this.employeeService.getEmployee(id)
      .subscribe({
        next: (employee: Employee) => this.displayEmployee(employee),
        error: err => this.errorMessage = err
      });
  }

  displayEmployee(employee: Employee): void {
    if (this.employeeForm) {
      this.employeeForm.reset();
    }
    this.Employee = employee;

    if (this.Employee.id === 0) {
      this.pageTitle = 'Add Employee';
    } else {
      this.pageTitle = `Edit Employee: ${this.Employee.Name}`;
    }

    // Update the data on the form
    this.employeeForm.patchValue({
      Name: this.Employee.Name,
      Qualification: this.Employee.Qualification,
      Experience: this.Employee.Experience,
      Languages: this.Employee.Languages
    });
    this.employeeForm.setControl('Languages', this.fb.control(this.Employee.Languages || []));
  }

  onSubmit(): void {
    if(this.employeeForm.valid) {
      if(this.employeeForm.dirty){
        const e = {...this.Employee, ...this.employeeForm.value};

        if(e.id === 0)
        {
          this.employeeService.createEmployee(e)
          .subscribe({
            next: () => this.onSaveComplete(),
            error: err => this.errorMessage = err
          });
        } else {
          this.employeeService.updateEmployee(e)
          .subscribe({
            next: () => this.onSaveComplete(),
            error: err => this.errorMessage = err
          });
        }
      }
    }
  }

  onSaveComplete(): void {
    this.employeeForm.reset();
    this.router.navigate(['/employee']);
  }

  deleteEmployee(): void {
    if (this.Employee.id === 0) {
      this.onSaveComplete();
    } else {
      if(confirm(`Really delete the employee: ${this.Employee.Name}?`)) {
        this.employeeService.deleteEmployee(this.Employee.id)
        .subscribe({
          next: () => this.onSaveComplete(),
          error: err => this.errorMessage = err
        });
      }
    }
  }
}
