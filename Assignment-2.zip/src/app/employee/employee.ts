export interface Employee {
  id: number;
  Name: string;
  Qualification: string;
  Experience: number;
  Languages: any[];
}
