import { InMemoryDbService } from 'angular-in-memory-web-api' ;
import { Employee } from './employee';


export class EmployeeData implements InMemoryDbService {
  createDb() {
    const employees: Employee[] = [
      {
        id: 1,
        Name: 'Shweta',
        Qualification: 'Bachelor',
        Experience: 3,
        Languages: [
                    'Marathi',
                    'English',
                    'Hindi',
                    'Kannada'
        ]
      },
      {
        id: 2,
        Name: 'Shreya',
        Qualification: 'Masters',
        Experience: 4,
        Languages: [
                    'Gujarathi',
                    'English',
                    'Hindi'
        ]
      },
      {
        id : 3,
        Name: 'Ayesha',
        Qualification: 'doctorate',
        Experience: 6,
        Languages: [
                    'English',
                    'Hindi'
        ]
      }
  ];
    return {employees};
  }

}
