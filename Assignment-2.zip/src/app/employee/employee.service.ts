import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule, HttpHeaders } from '@angular/common/http';
import { Observable, throwError, of } from 'rxjs';
import { Employee } from './employee';
import { tap, catchError, map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  private employeeUrl = 'api/employees';

  constructor(private http: HttpClient) { }

  getEmplyees(): Observable<Employee[]> {
    return this.http.get<Employee[]>(this.employeeUrl)
          .pipe(
            tap( data => console.log(JSON.stringify(data))),
            catchError(this.handleError)
          );
  }

  getEmployee(id: number): Observable<Employee> {
    if (id === 0 )
    {
      return of(this.initializeEmployee());
    }
    const url = `${this.employeeUrl}/${id}`;
    return this.http.get<Employee>(url)
    .pipe(
      tap(data => console.log('get Employee: ' + JSON.stringify(data))),
      catchError(this.handleError)
    );
    }

    createEmployee(employee: Employee): Observable<Employee> {
      const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
      employee.id= null;
      return this.http.post<Employee>(this.employeeUrl, employee, { headers })
             .pipe(
               tap(data => console.log('createEmployee: ' + JSON.stringify(data))),
               catchError(this.handleError)
             );
    }

    deleteEmployee(id: number): Observable<Employee> {
      const headers = new HttpHeaders({ 'Content-Type' : 'application/json'});
      const url = `${this.employeeUrl}/${id}`;
      return this.http.delete<Employee>(url, {headers})
             .pipe(
               tap(data => console.log('deleteEmployee: ' + id)),
               catchError(this.handleError)
             );
    }

    updateEmployee(employee: Employee): Observable<Employee> {
      const headers = new HttpHeaders({ 'Content-Type' : 'application/json'});
      const url = `${this.employeeUrl}/${employee.id}`;
      return this.http.put<Employee>(url, employee, {headers})
             .pipe(
               tap(data => console.log('updateEmployee:' + employee.id )),
               map(() => employee),
               catchError(this.handleError)
             );
    }

  private handleError( err ) {
    let errorMessage: string;
    if(err.error instanceof ErrorEvent){
        errorMessage = `an error occured: ${err.error.message}`;
    } else {
      errorMessage = `backend returned code ${err.status} : ${err.body.error}`;
    }
    console.error(err);
    return throwError(errorMessage);
  }

  private initializeEmployee(): Employee {
    return {
      id: 0,
      Name: null,
      Experience: null,
      Languages: null,
      Qualification: null
    };
  }
}
