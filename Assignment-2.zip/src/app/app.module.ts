import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { EmployeeListComponent } from './employee/employee-list.component';
import { InMemoryWebApiModule } from 'angular-in-memory-web-api';
import { EmployeeData } from './employee/employee-data';
import { RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { EmployeeAddComponent } from './employee/employee-add.component';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule, FormsModule } from '@angular/forms'

@NgModule({
  declarations: [
    AppComponent,
    EmployeeListComponent,
    EmployeeAddComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    InMemoryWebApiModule.forRoot( EmployeeData ),
    RouterModule.forRoot([
      {path: 'employee', component: EmployeeListComponent},
      {path: 'employee/:id', component: EmployeeAddComponent},
      {path: 'employee/:id/edit', component: EmployeeAddComponent},
      {path: 'home', component: HomeComponent },
      {path: '**', component: HomeComponent, pathMatch: 'full'},
      {path: '', component: HomeComponent, pathMatch: 'full'}
    ]
    ),
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
