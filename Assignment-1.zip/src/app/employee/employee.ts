export interface IEmployee {
  Id: number;
  Name: string;
  Qualification: string;
  Experience: number;
  Languages: any[];
}
