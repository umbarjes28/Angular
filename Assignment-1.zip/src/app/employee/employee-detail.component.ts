import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-employee-detail',
  templateUrl: './employee-detail.component.html',
  styleUrls: ['./employee-detail.component.css']
})
export class EmployeeDetailComponent implements OnInit {
  pageTitle = 'Add Employee';
  formVar: FormGroup;
  constructor(private fb: FormBuilder) { }

  ngOnInit() {
    this.formVar = this.fb.group({
      Id: 0,
      Name: ['', [
        Validators.required,
        Validators.minLength(4)]],
      Qualification: ['', Validators.required],
      Experience: ['', Validators.required],
      Languages : ['', Validators.required]
    });
  }
  onSubmit(): void {
    console.log(this.formVar.value);
  }

}
